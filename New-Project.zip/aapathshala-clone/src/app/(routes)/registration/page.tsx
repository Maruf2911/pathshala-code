'use client';

import type React from 'react';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

const RegistrationPage = () => {
  const router = useRouter();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (formData.password !== formData.confirmPassword) {
      alert('Passwords do not match');
      return;
    }

    setLoading(true);

    // In a real implementation, we would send this data to a backend
    setTimeout(() => {
      setLoading(false);
      alert('This is a demo site. Registration functionality is not active.');
      // router.push('/login'); // We would navigate to login in a real implementation
    }, 1000);
  };

  return (
    <div className="container mx-auto">
      <div className="my-5 pt-5">
        <div className="max-w-md mx-auto bg-white rounded-lg shadow-md p-8">
          <form className="space-y-4" onSubmit={handleSubmit}>
            <h2 className="text-2xl font-bold text-center mb-6">Registration</h2>

            <div>
              <label htmlFor="name" className="block mb-1">Full Name</label>
              <input
                type="text"
                id="name"
                name="name"
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-aap-red"
                placeholder="Enter your full name"
                required
                value={formData.name}
                onChange={handleChange}
              />
            </div>

            <div>
              <label htmlFor="email" className="block mb-1">Email Address</label>
              <input
                type="email"
                id="email"
                name="email"
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-aap-red"
                placeholder="Enter your email address"
                required
                value={formData.email}
                onChange={handleChange}
              />
            </div>

            <div>
              <label htmlFor="phone" className="block mb-1">Phone Number</label>
              <input
                type="tel"
                id="phone"
                name="phone"
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-aap-red"
                placeholder="Enter your phone number"
                required
                value={formData.phone}
                onChange={handleChange}
              />
            </div>

            <div>
              <label htmlFor="password" className="block mb-1">Password</label>
              <input
                type="password"
                id="password"
                name="password"
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-aap-red"
                placeholder="Choose a password"
                required
                value={formData.password}
                onChange={handleChange}
              />
            </div>

            <div>
              <label htmlFor="confirmPassword" className="block mb-1">Confirm Password</label>
              <input
                type="password"
                id="confirmPassword"
                name="confirmPassword"
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-aap-red"
                placeholder="Confirm your password"
                required
                value={formData.confirmPassword}
                onChange={handleChange}
              />
            </div>

            <button
              type="submit"
              className="w-full bg-aap-red text-white py-2 rounded hover:opacity-90 transition-opacity"
              disabled={loading}
            >
              {loading ? 'Processing...' : 'Register'}
            </button>

            <p className="text-sm text-center">
              Already have an account? <Link href="/login" className="text-aap-red hover:underline">Log In Here</Link>
            </p>
          </form>
        </div>
      </div>

      {/* Help Video Section */}
      <div className="max-w-3xl mx-auto my-8">
        <div className="aspect-video bg-gray-200 rounded-lg flex items-center justify-center">
          <div className="text-center p-4">
            <p className="text-gray-600">Registration & Login Help Video</p>
            <p className="text-sm text-gray-500">(Video placeholder - in real implementation, this would be an actual embedded video)</p>
          </div>
        </div>

        <div className="flex flex-wrap justify-center gap-2 mt-4">
          <button className="px-4 py-2 border border-aap-red text-aap-red rounded-lg hover:bg-aap-red hover:text-white transition-colors">
            কীভাবে একাউন্ট তৈরী করব ?
          </button>
          <button className="px-4 py-2 border border-aap-red text-aap-red rounded-lg hover:bg-aap-red hover:text-white transition-colors">
            কীভাবে লগইন করব ?
          </button>
          <button className="px-4 py-2 border border-aap-red text-aap-red rounded-lg hover:bg-aap-red hover:text-white transition-colors">
            কীভাবে কোর্স এনরোল করব ?
          </button>
        </div>
      </div>
    </div>
  );
};

export default RegistrationPage;
