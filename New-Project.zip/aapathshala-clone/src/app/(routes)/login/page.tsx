'use client';

import type React from 'react';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

const LoginPage = () => {
  const router = useRouter();
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // In a real implementation, we would connect to a backend here
    setTimeout(() => {
      setLoading(false);
      alert('This is a demo site. Login functionality is not active.');
      // router.push('/dashboard'); // We would navigate to the dashboard in a real implementation
    }, 1000);
  };

  return (
    <div className="container mx-auto">
      <div className="my-5 pt-5">
        <div className="max-w-md mx-auto bg-white rounded-lg shadow-md p-8">
          <form className="space-y-4" onSubmit={handleSubmit}>
            <h2 className="text-2xl font-bold text-center mb-6">Login</h2>

            <div>
              <label htmlFor="username" className="block mb-1">Enter Your Roll</label>
              <input
                type="text"
                id="username"
                name="username"
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-aap-red"
                placeholder="AAPXXXXX"
                required
                value={formData.username}
                onChange={handleChange}
              />
            </div>

            <div>
              <label htmlFor="password" className="block mb-1">Password</label>
              <input
                type="password"
                id="password"
                name="password"
                className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-aap-red"
                required
                value={formData.password}
                onChange={handleChange}
              />
            </div>

            <button
              type="submit"
              className="w-full bg-aap-red text-white py-2 rounded hover:opacity-90 transition-opacity"
              disabled={loading}
            >
              {loading ? 'Loading...' : 'Login'}
            </button>

            <p className="text-sm">
              Forgot my password. <Link href="/forgot-pass" className="text-aap-red hover:underline">Reset Here</Link>
            </p>

            <p className="text-sm">
              Forgot your Roll? <Link href="/forgotroll" className="text-aap-red hover:underline">Click Here</Link>
            </p>

            <p className="text-sm">
              Don't Have a Roll Number? <Link href="/registration" className="text-aap-red hover:underline">Register Now!</Link> It's Simple
            </p>
          </form>
        </div>
      </div>

      {/* Help Video Section */}
      <div className="max-w-3xl mx-auto my-8">
        <div className="aspect-video bg-gray-200 rounded-lg flex items-center justify-center">
          <div className="text-center p-4">
            <p className="text-gray-600">Registration & Login Help Video</p>
            <p className="text-sm text-gray-500">(Video placeholder - in real implementation, this would be an actual embedded video)</p>
          </div>
        </div>

        <div className="flex flex-wrap justify-center gap-2 mt-4">
          <button className="px-4 py-2 border border-aap-red text-aap-red rounded-lg hover:bg-aap-red hover:text-white transition-colors">
            কীভাবে একাউন্ট তৈরী করব ?
          </button>
          <button className="px-4 py-2 border border-aap-red text-aap-red rounded-lg hover:bg-aap-red hover:text-white transition-colors">
            কীভাবে লগইন করব ?
          </button>
          <button className="px-4 py-2 border border-aap-red text-aap-red rounded-lg hover:bg-aap-red hover:text-white transition-colors">
            কীভাবে কোর্স এনরোল করব ?
          </button>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
