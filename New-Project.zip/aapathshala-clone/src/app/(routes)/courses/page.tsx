'use client';

import React, { useState, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import CourseCard from '@/components/ui/CourseCard';
import CourseFiltersAndGrid from './CourseFiltersAndGrid';

const Loading = () => (
  <div className="container mx-auto px-4 py-12 text-center">
    <p className="text-xl">Loading courses...</p>
  </div>
);

// Sample course data for demonstration
const allCoursesData = [
  {
    id: 'TPS25',
    title: 'HSC-25 : টাইমলি প্রস্তুতি সিরিজ',
    description: 'একক অধ্যায়ভিত্তিক মাস্টার ক্লাস থেকে শুরু অধ্যায় শেষে ফাইনাল মডেল টেস্ট OMR দিয়ে',
    imageUrl: 'https://ext.same-assets.com/1245627468/3899574073.jpeg',
    category: 'hsc-25',
    features: [
      { id: 'f1-tps25', text: 'অধ্যায়ভিত্তিক মাস্টার ক্লাস' },
      { id: 'f2-tps25', text: 'অধ্যায়ভিত্তিক MCQ প্র্যাকটিস' },
      { id: 'f3-tps25', text: 'অধ্যায়ভিত্তিক লিখিত প্র্যাকটিস' },
      { id: 'f4-tps25', text: 'ফাইনাল মডেল টেস্ট' },
    ]
  },
  {
    id: 'bbc26c1',
    title: 'BBC-26 : বোর্ড বুক কোর্স (টাইমলি-১)',
    description: 'টাইমলি অধ্যায়ভিত্তিক মাস্টার ক্লাস বোর্ড বই অনুসারে / ক্লাস টেস্ট সহ',
    imageUrl: 'https://ext.same-assets.com/1245627468/3233133526.png',
    category: 'hsc-26',
    features: [
      { id: 'f1-bbc26c1', text: 'অধ্যায়ভিত্তিক মাস্টার ক্লাস' },
      { id: 'f2-bbc26c1', text: 'অধ্যায়ভিত্তিক ক্লাস টেস্ট' },
      { id: 'f3-bbc26c1', text: 'লিমিটেড মডেল টেস্ট' },
      { id: 'f4-bbc26c1', text: 'ক্লাস রুটিন অনুসারে ক্লাস' },
    ]
  },
  {
    id: 'bbc25c3',
    title: 'BBC-25 : বোর্ড বুক কোর্স (ফুল-৩)',
    description: 'বোর্ড বই মাস্টার ক্লাস / ক্লাস টেস্ট সহ',
    imageUrl: 'https://ext.same-assets.com/1245627468/3487475696.png',
    category: 'hsc-25',
    features: [
      { id: 'f1-bbc25c3', text: 'অধ্যায়ভিত্তিক মাস্টার ক্লাস' },
      { id: 'f2-bbc25c3', text: 'অধ্যায়ভিত্তিক ক্লাস টেস্ট' },
      { id: 'f3-bbc25c3', text: 'লিমিটেড মডেল টেস্ট' },
      { id: 'f4-bbc25c3', text: 'ক্লাস রুটিন অনুসারে ক্লাস' },
    ]
  },
  {
    id: 'bbc25c2',
    title: 'BBC-25 : বোর্ড বুক কোর্স (ফুল-২)',
    description: 'টাইমলি অধ্যায়ভিত্তিক মাস্টার ক্লাস বোর্ড বই অনুসারে / ক্লাস টেস্ট সহ',
    imageUrl: 'https://ext.same-assets.com/1245627468/3565386264.jpeg',
    category: 'hsc-25',
    features: [
      { id: 'f1-bbc25c2', text: 'অধ্যায়ভিত্তিক মাস্টার ক্লাস' },
      { id: 'f2-bbc25c2', text: 'অধ্যায়ভিত্তিক ক্লাস টেস্ট' },
      { id: 'f3-bbc25c2', text: 'লিমিটেড মডেল টেস্ট' },
      { id: 'f4-bbc25c2', text: 'ক্লাস রুটিন অনুসারে ক্লাস' },
    ]
  },
  {
    id: 'vap24',
    title: 'ভার্সিটি এডমিশন প্রোগ্রাম : ২০২৪',
    description: 'বিশ্ববিদ্যালয়ের ভর্তি পরীক্ষার জন্য সম্পূর্ণ প্রস্তুতি / QNA সহ Unlimited মডেল টেস্ট',
    imageUrl: 'https://ext.same-assets.com/1245627468/2494758884.jpeg',
    category: 'hsc-24',
    features: [
      { id: 'f1-vap24', text: 'বিষয়ভিত্তিক মাস্টার ক্লাস' },
      { id: 'f2-vap24', text: 'অধ্যায়ভিত্তিক টেস্ট' },
      { id: 'f3-vap24', text: 'মডেল টেস্ট' },
      { id: 'f4-vap24', text: 'ফাইনাল রিভিশন' },
    ]
  },
  {
    id: 'map24',
    title: 'মেডিকেল এডমিশন প্রোগ্রাম : ২০২৪',
    description: 'মেডিকেল ভর্তি পরীক্ষার জন্য সম্পূর্ণ প্রস্তুতি / QNA সহ Unlimited মডেল টেস্ট',
    imageUrl: 'https://ext.same-assets.com/1245627468/4285502629.jpeg',
    category: 'hsc-24',
    features: [
      { id: 'f1-map24', text: 'বিষয়ভিত্তিক মাস্টার ক্লাস' },
      { id: 'f2-map24', text: 'অধ্যায়ভিত্তিক টেস্ট' },
      { id: 'f3-map24', text: 'মডেল টেস্ট' },
      { id: 'f4-map24', text: 'ফাইনাল রিভিশন' },
    ]
  },
  {
    id: 'eap24',
    title: 'ইঞ্জিনিয়ারিং এডমিশন প্রোগ্রাম : ২০২৪',
    description: 'ইঞ্জিনিয়ারিং ভর্তি পরীক্ষার জন্য সম্পূর্ণ প্রস্তুতি / QNA সহ Unlimited মডেল টেস্ট',
    imageUrl: 'https://ext.same-assets.com/1245627468/1794308751.jpeg',
    category: 'hsc-24',
    features: [
      { id: 'f1-eap24', text: 'বিষয়ভিত্তিক মাস্টার ক্লাস' },
      { id: 'f2-eap24', text: 'অধ্যায়ভিত্তিক টেস্ট' },
      { id: 'f3-eap24', text: 'মডেল টেস্ট' },
      { id: 'f4-eap24', text: 'ফাইনাল রিভিশন' },
    ]
  },
  {
    id: 'hsc23mt',
    title: 'HSC-2023 : Academic Final Formulation Course',
    description: 'Main Book MCQ Practice, Board MCQ Practice, Quick Revision Materials, Test Paper Live Exam',
    imageUrl: 'https://ext.same-assets.com/1245627468/3940952122.jpeg',
    category: 'hsc-23',
    features: [
      { id: 'f1-hsc23mt', text: 'Main Book MCQ Practice' },
      { id: 'f2-hsc23mt', text: 'Board MCQ Practice' },
      { id: 'f3-hsc23mt', text: 'Quick Revision Materials' },
      { id: 'f4-hsc23mt', text: 'Test Paper & Final Model Test' },
    ]
  },
];

const CoursesPage = () => {
  return (
    <Suspense fallback={<Loading />}>
      <CourseFiltersAndGrid />
    </Suspense>
  );
};

export default CoursesPage;
