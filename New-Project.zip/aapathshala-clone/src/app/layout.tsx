import type { Metadata } from "next";
import { Hind_Siliguri } from "next/font/google";
import "./globals.css";

import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import ClientBody from "./ClientBody";

const hindSiliguri = Hind_Siliguri({
  subsets: ["latin", "bengali"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-hind-siliguri",
});

export const metadata: Metadata = {
  title: "Academic & Admission Pathshala",
  description: "শিক্ষায়, চর্চায় ও সহযোগিতায় পাশে আছি আমরা । প্রবেশ করো তোমার স্বপ্ন ছোঁয়ার কোর্সে",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${hindSiliguri.variable} font-sans`}>
        <ClientBody>
          <Navbar />
          <main className="min-h-screen pt-16">{children}</main>
          <Footer />
        </ClientBody>
      </body>
    </html>
  );
}
