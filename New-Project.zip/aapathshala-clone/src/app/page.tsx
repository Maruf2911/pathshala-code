import Banner from '@/components/ui/Banner';
import QuickLinks from '@/components/ui/QuickLinks';
import FeaturedCourses from '@/components/ui/FeaturedCourses';
import NotificationBanner from '@/components/ui/NotificationBanner';

export default function Home() {
  const notificationContent = (
    <>
      <h3 className="font-bold text-center mb-4">লিমিটেড অফারসমূহ - ২০২৪</h3>
      <p className="mb-4">অপাঠশালার অফারসমূহ একদম একদম তাতকা। আমাদের অফারগুলি বিভিন্ন সময়ে বিভিন্ন অফার লাইভ করা হয়ে থাকে।</p>

      <div className="mb-2 font-semibold">রুপম</div>
      <ol className="list-decimal pl-5 mb-4">
        <li>অপাঠশালায় ভর্তির উদ্দেশ্য কুল করুন</li>
        <li>নিজের নাম সর্বনিম্ন বারে রাখুন</li>
        <li>কোর্স ভর্তিতে ৫০% ডিস্কাউন্ট এপ্লাই করিতে পারিবেন</li>
        <li>সেরিয়াস স্টুডেন্ট মাত্র বিবেচিত</li>
        <li>অফারসমূহ সীমিত, সর্বশেষে পরিবর্তনযোগ্য</li>
      </ol>

      <p className="text-xs italic text-gray-500 text-center">* অফারসমূহ হ্রাস বৃদ্ধি করণ করার একমাত্র ক্ষমতা অপাঠশালা কর্তৃপক্ষের হাতে থাকবে।</p>
    </>
  );

  return (
    <>
      <NotificationBanner
        title="লিমিটেড অফারসমূহ - ২০২৪"
        content={notificationContent}
      />

      <Banner />

      <QuickLinks />

      <FeaturedCourses />
    </>
  )
}
