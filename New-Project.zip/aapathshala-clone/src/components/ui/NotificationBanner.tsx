'use client';

import type React from 'react';
import { useState } from 'react';
import { X } from 'lucide-react';

interface NotificationBannerProps {
  title: string;
  content: React.ReactNode;
  isOpen?: boolean;
}

const NotificationBanner = ({ title, content, isOpen = true }: NotificationBannerProps) => {
  const [isVisible, setIsVisible] = useState(isOpen);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 bg-black/50" onClick={() => setIsVisible(false)}>
      <div
        className="bg-white rounded-lg shadow-lg max-w-md w-full p-6 mx-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-aap-red">{title}</h2>
          <button
            onClick={() => setIsVisible(false)}
            className="text-gray-500 hover:text-gray-700"
            aria-label="Close notification"
          >
            <X size={20} />
          </button>
        </div>

        <div className="text-gray-800 prose prose-sm max-w-none">
          {content}
        </div>

        <div className="mt-6 text-center">
          <button
            onClick={() => setIsVisible(false)}
            className="bg-aap-red text-white px-4 py-2 rounded hover:opacity-90 transition-opacity"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default NotificationBanner;
