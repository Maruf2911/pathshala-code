'use client';

import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { BsCheck2Circle } from 'react-icons/bs';

interface CourseFeature {
  id: string;
  text: string;
}

interface CourseCardProps {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  features: CourseFeature[];
}

const CourseCard = ({ id, title, description, imageUrl, features }: CourseCardProps) => {
  return (
    <div className="course-card flex flex-col h-full">
      {/* Course Image */}
      <div className="relative h-48 w-full">
        <Image
          src={imageUrl}
          alt={title}
          fill
          className="object-cover"
        />
      </div>

      {/* Course Content */}
      <div className="p-4 flex flex-col flex-grow">
        <h3 className="text-lg font-semibold mb-2">{title}</h3>
        <p className="text-sm text-gray-600 mb-4">{description}</p>

        {/* Course Features */}
        <div className="space-y-2 mb-6 flex-grow">
          {features.map((feature) => (
            <div key={feature.id} className="flex items-center">
              <span className="mr-2 text-aap-red">
                <BsCheck2Circle size={16} />
              </span>
              <span className="text-sm">{feature.text}</span>
            </div>
          ))}
        </div>

        {/* Enroll Button */}
        <Link href={`/checkout/${id}`} className="enroll-button mt-auto">
          Enroll Now
        </Link>
      </div>
    </div>
  );
};

export default CourseCard;
