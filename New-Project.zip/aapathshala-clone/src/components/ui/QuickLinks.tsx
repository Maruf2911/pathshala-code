'use client';

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { HiOutlineQuestionMarkCircle, HiOutlineBookOpen, HiOutlineClipboardCheck, HiOutlineInformationCircle } from 'react-icons/hi';

// Quick links data
const quickLinksData = [
  {
    id: 'question-bank',
    title: 'প্রশ্নব্যাংক ছুঁই',
    icon: <HiOutlineQuestionMarkCircle size={32} />,
    iconBg: 'bg-aap-red',
    description: 'সবচেয়ে বড় জাতীয় ও বিশ্ববিদ্যালয় প্রশ্নব্যাংক',
    link: '/qbs'
  },
  {
    id: 'pdf-library',
    title: 'ডিজিটাল লাইব্রেরী',
    icon: <HiOutlineBookOpen size={32} />,
    iconBg: 'bg-aap-blue',
    description: 'সব বিষয়ের নোট, বুক আর সাজেশন',
    link: '/library'
  },
  {
    id: 'exam-practice',
    title: 'পরীক্ষা দাও',
    icon: <HiOutlineClipboardCheck size={32} />,
    iconBg: 'bg-aap-yellow',
    description: 'দক্ষতা যাচাই করো নিজের সাথে',
    link: '/exams'
  },
  {
    id: 'admission-info',
    title: 'ভর্তি তথ্য',
    icon: <HiOutlineInformationCircle size={32} />,
    iconBg: 'bg-green-500',
    description: 'সকল বিশ্ববিদ্যালয়ের ভর্তি সংক্রান্ত তথ্য',
    link: '/adinfo/info'
  }
];

const QuickLinks = () => {
  return (
    <section className="py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-10">
          শেখার নতুন গতি
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {quickLinksData.map((item) => (
            <Link key={item.id} href={item.link} className="block">
              <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-6 text-center h-full flex flex-col items-center">
                <div className={`${item.iconBg} text-white p-3 rounded-full mb-4`}>
                  {item.icon}
                </div>
                <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                <p className="text-sm text-gray-600">{item.description}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default QuickLinks;
