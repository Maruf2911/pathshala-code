'use client';

import React from 'react';
import Image from 'next/image';
import Link from 'next/link';

const Banner = () => {
  return (
    <div className="bg-gradient-to-r from-[#f8f9fa] to-[#e9ecef] py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          {/* Left Section - Text Content */}
          <div className="text-center md:text-left">
            <h1 className="text-3xl md:text-4xl font-bold mb-4 text-[#2c282c]">
              শিক্ষায়, চর্চায় ও সহযোগিতায় পাশে আছি আমরা
            </h1>
            <h2 className="text-xl md:text-2xl text-aap-red font-bold mb-6">
              প্রবেশ করো তোমার স্বপ্ন ছোঁয়ার কোর্সে
            </h2>
            <p className="text-gray-700 mb-8">
              অনলাইনে AAP এর সাথে প্রস্তুতি জন্য নিচের কোর্সগুলো থেকে ইচ্ছের কোর্সে Enroll করে শুরু করো তোমার অগ্নি
            </p>

            <div className="flex flex-wrap justify-center md:justify-start gap-2 mb-6">
              <Link
                href="/courses?filter=hsc-26"
                className="px-4 py-2 bg-white text-aap-red border border-aap-red rounded-full hover:bg-aap-red hover:text-white transition-colors"
              >
                HSC-26
              </Link>
              <Link
                href="/courses?filter=hsc-25"
                className="px-4 py-2 bg-white text-aap-red border border-aap-red rounded-full hover:bg-aap-red hover:text-white transition-colors"
              >
                HSC-25
              </Link>
              <Link
                href="/courses?filter=hsc-24"
                className="px-4 py-2 bg-white text-aap-red border border-aap-red rounded-full hover:bg-aap-red hover:text-white transition-colors"
              >
                HSC-24
              </Link>
              <Link
                href="/courses?filter=hsc-23"
                className="px-4 py-2 bg-white text-aap-red border border-aap-red rounded-full hover:bg-aap-red hover:text-white transition-colors"
              >
                HSC-23
              </Link>
              <Link
                href="/courses?filter=old"
                className="px-4 py-2 bg-white text-aap-red border border-aap-red rounded-full hover:bg-aap-red hover:text-white transition-colors"
              >
                Old
              </Link>
            </div>
          </div>

          {/* Right Section - Image or Video */}
          <div className="relative h-64 md:h-80">
            <Image
              src="https://ext.same-assets.com/1245627468/3899574073.jpeg"
              alt="Aapathshala Banner"
              fill
              className="object-cover rounded-lg shadow-md"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Banner;
