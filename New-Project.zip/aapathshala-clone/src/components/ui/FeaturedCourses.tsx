'use client';

import React from 'react';
import CourseCard from './CourseCard';

// Sample course data
const coursesData = [
  {
    id: 'TPS25',
    title: 'HSC-25 : টাইমলি প্রস্তুতি সিরিজ',
    description: 'একক অধ্যায়ভিত্তিক মাস্টার ক্লাস থেকে শুরু অধ্যায় শেষে ফাইনাল মডেল টেস্ট OMR দিয়ে',
    imageUrl: 'https://ext.same-assets.com/1245627468/3899574073.jpeg',
    features: [
      { id: 'f1-tps25', text: 'অধ্যায়ভিত্তিক মাস্টার ক্লাস' },
      { id: 'f2-tps25', text: 'অধ্যায়ভিত্তিক MCQ প্র্যাকটিস' },
      { id: 'f3-tps25', text: 'অধ্যায়ভিত্তিক লিখিত প্র্যাকটিস' },
      { id: 'f4-tps25', text: 'ফাইনাল মডেল টেস্ট' },
    ]
  },
  {
    id: 'bbc26c1',
    title: 'BBC-26 : বোর্ড বুক কোর্স (টাইমলি-১)',
    description: 'টাইমলি অধ্যায়ভিত্তিক মাস্টার ক্লাস বোর্ড বই অনুসারে / ক্লাস টেস্ট সহ',
    imageUrl: 'https://ext.same-assets.com/1245627468/3233133526.png',
    features: [
      { id: 'f1-bbc26c1', text: 'অধ্যায়ভিত্তিক মাস্টার ক্লাস' },
      { id: 'f2-bbc26c1', text: 'অধ্যায়ভিত্তিক ক্লাস টেস্ট' },
      { id: 'f3-bbc26c1', text: 'লিমিটেড মডেল টেস্ট' },
      { id: 'f4-bbc26c1', text: 'ক্লাস রুটিন অনুসারে ক্লাস' },
    ]
  },
  {
    id: 'bbc25c3',
    title: 'BBC-25 : বোর্ড বুক কোর্স (ফুল-৩)',
    description: 'বোর্ড বই মাস্টার ক্লাস / ক্লাস টেস্ট সহ',
    imageUrl: 'https://ext.same-assets.com/1245627468/3487475696.png',
    features: [
      { id: 'f1-bbc25c3', text: 'অধ্যায়ভিত্তিক মাস্টার ক্লাস' },
      { id: 'f2-bbc25c3', text: 'অধ্যায়ভিত্তিক ক্লাস টেস্ট' },
      { id: 'f3-bbc25c3', text: 'লিমিটেড মডেল টেস্ট' },
      { id: 'f4-bbc25c3', text: 'ক্লাস রুটিন অনুসারে ক্লাস' },
    ]
  },
  {
    id: 'bbc25c2',
    title: 'BBC-25 : বোর্ড বুক কোর্স (ফুল-২)',
    description: 'টাইমলি অধ্যায়ভিত্তিক মাস্টার ক্লাস বোর্ড বই অনুসারে / ক্লাস টেস্ট সহ',
    imageUrl: 'https://ext.same-assets.com/1245627468/3565386264.jpeg',
    features: [
      { id: 'f1-bbc25c2', text: 'অধ্যায়ভিত্তিক মাস্টার ক্লাস' },
      { id: 'f2-bbc25c2', text: 'অধ্যায়ভিত্তিক ক্লাস টেস্ট' },
      { id: 'f3-bbc25c2', text: 'লিমিটেড মডেল টেস্ট' },
      { id: 'f4-bbc25c2', text: 'ক্লাস রুটিন অনুসারে ক্লাস' },
    ]
  },
];

const FeaturedCourses = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-12">
          ফিচার্ড কোর্সসমূহ
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {coursesData.map((course) => (
            <CourseCard
              key={course.id}
              id={course.id}
              title={course.title}
              description={course.description}
              imageUrl={course.imageUrl}
              features={course.features}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedCourses;
