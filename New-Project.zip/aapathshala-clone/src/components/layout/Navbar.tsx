'use client';

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';

const Navbar = () => {
  return (
    <nav id="HomeMainNav" className="fixed top-0 left-0 w-full bg-white shadow-sm z-50">
      <div className="container mx-auto px-4 py-2 flex items-center justify-between">
        <Link href="/" className="navbar-brand">
          <Image
            src="https://ext.same-assets.com/1245627468/2932206556.png"
            alt="Aapathshala Logo"
            width={150}
            height={40}
            className="h-9 w-auto"
          />
        </Link>

        <div className="quicklinks quicklinks-middle">
          <ul className="flex space-x-4">
            <li><Link href="/qbs" className="navbar-menu-item hover:text-aap-red">প্রশ্নব্যাংক</Link></li>
            <li><Link href="#" className="navbar-menu-item hover:text-aap-red">ক্লাস</Link></li>
            <li><Link href="/exams" className="navbar-menu-item hover:text-aap-red">পরীক্ষা</Link></li>
            <li><Link href="/library" className="navbar-menu-item hover:text-aap-red">PDF</Link></li>
            <li><Link href="/adinfo/info" className="navbar-menu-item hover:text-aap-red">তথ্য</Link></li>
            <li><Link href="/courses" className="navbar-menu-item hover:text-aap-red">কোর্স</Link></li>
            <li><Link href="/care" className="navbar-menu-item hover:text-aap-red">কেয়ার</Link></li>
          </ul>
        </div>

        <div className="flex items-center space-x-2">
          <Link
            href="/login"
            className="text-sm bg-white font-medium hover:text-aap-red px-4 py-2 rounded-full border border-transparent"
          >
            Log In
          </Link>
          <Link
            href="/registration"
            className="text-sm bg-aap-red text-white font-medium px-4 py-2 rounded-full hover:opacity-90 transition-opacity"
          >
            Sign Up
          </Link>
        </div>
      </div>

      <div className="quicklinks quicklinks-bottom md:hidden container mx-auto px-4 pb-2">
        <ul className="flex flex-wrap justify-center space-x-3">
          <li><Link href="/qbs" className="navbar-menu-item hover:text-aap-red text-xs">প্রশ্নব্যাংক</Link></li>
          <li><Link href="#" className="navbar-menu-item hover:text-aap-red text-xs">ক্লাস</Link></li>
          <li><Link href="/exams" className="navbar-menu-item hover:text-aap-red text-xs">পরীক্ষা</Link></li>
          <li><Link href="/library" className="navbar-menu-item hover:text-aap-red text-xs">PDF</Link></li>
          <li><Link href="/adinfo/info" className="navbar-menu-item hover:text-aap-red text-xs">তথ্য</Link></li>
          <li><Link href="/courses" className="navbar-menu-item hover:text-aap-red text-xs">কোর্স</Link></li>
          <li><Link href="/care" className="navbar-menu-item hover:text-aap-red text-xs">কেয়ার</Link></li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
