'use client';

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { FaFacebook, FaYoutube, FaTelegram, FaUsers } from 'react-icons/fa';

const Footer = () => {
  return (
    <footer className="bg-[#212529] text-white pt-8 pb-4">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Logo and Tagline */}
          <div className="text-center md:text-left">
            <Link href="/" className="inline-block mb-4">
              <Image
                src="https://ext.same-assets.com/1245627468/2932206556.png"
                alt="Aapathshala Logo"
                width={180}
                height={50}
                className="h-12 w-auto"
              />
            </Link>
            <h2 className="text-xl font-bold mb-4">PATHSHALA IS LOVE</h2>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="footer-heading uppercase">Quick Links</h3>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Link href="/qbs" className="footer-link">Question Bank</Link>
                <Link href="#" className="footer-link">Pathshala Class</Link>
                <Link href="/exams" className="footer-link">Pathshala Exam</Link>
                <Link href="/library" className="footer-link">Digital Library</Link>
              </div>
              <div>
                <Link href="https://www.aaplibrary.com/" className="footer-link">Pathshala Library</Link>
                <Link href="/adinfo/info" className="footer-link">Eligibility Checker</Link>
                <Link href="/barta" className="footer-link">Pathshala Barta</Link>
                <Link href="/join-us" className="footer-link">Join With Us</Link>
              </div>
            </div>
          </div>

          {/* Contact Info */}
          <div className="text-center md:text-left">
            <h3 className="footer-heading uppercase">জরুরী হেল্পলাইন</h3>
            <Link href="tel:+8801710090043" className="footer-link flex items-center justify-center md:justify-start">
              <span className="mr-2">&#9742;</span> +880 1710-090043
            </Link>
            <Link href="tel:+8801310010067" className="footer-link flex items-center justify-center md:justify-start">
              <span className="mr-2">&#9742;</span> +880 1310-010067
            </Link>
            <Link href="mailto:aapathshala09@gmail.com" className="footer-link flex items-center justify-center md:justify-start">
              <span className="mr-2">&#9993;</span> aapathshala09@gmail.com
            </Link>
          </div>
        </div>

        {/* Social Media */}
        <div className="flex justify-center space-x-4 mb-6">
          <a href="https://www.facebook.com/groups/AAPathshala/" target="_blank" rel="noopener noreferrer" className="social-icon">
            <FaFacebook size={18} />
          </a>
          <a href="https://www.youtube.com/@aapathshala" target="_blank" rel="noopener noreferrer" className="social-icon">
            <FaYoutube size={18} />
          </a>
          <a href="https://t.me/aaptg" target="_blank" rel="noopener noreferrer" className="social-icon">
            <FaTelegram size={18} />
          </a>
          <a href="https://www.facebook.com/groups/AAPathshala/" target="_blank" rel="noopener noreferrer" className="social-icon">
            <FaUsers size={18} />
          </a>
        </div>

        {/* Copyright */}
        <div className="text-center text-sm text-gray-400">
          Copyright © <span className="text-aap-red">AAPATHSHALA.COM</span> | All rights reserved!
        </div>
      </div>
    </footer>
  );
};

export default Footer;
